module.exports = {
  filenameHashing: false,
  devServer: {
    allowedHosts: [
      'quickfind.local',
      'localhost'
    ]
  },
}
